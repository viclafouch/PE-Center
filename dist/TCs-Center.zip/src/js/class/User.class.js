/* User Object */

export default class User {

    constructor(string) {

       this.name = string;
    }
}